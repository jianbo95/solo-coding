class ProbabilityStrategy {
    constructor() {
        this.name = '概率分析策略';
    }
    analyze(grid, rows, cols, totalMines) {
        const unrevealedCells = [];
        const regions = this.identifyRegions(grid, rows, cols);
        
        // 获取所有未揭开的格子
        for (let row = 0; row < rows; row++) {
            for (let col = 0; col < cols; col++) {
                const cell = grid.grid[row][col];
                if (!cell.revealed && !cell.flagged) {
                    unrevealedCells.push({ row, col });
                }
            }
        }

        // 如果没有未揭开的格子，返回null
        if (unrevealedCells.length === 0) return null;

        // 计算每个未揭开格子的雷概率
        const probabilities = new Map();
        for (const {row, col} of unrevealedCells) {
            const probability = this.calculateProbability(grid, row, col, regions);
            probabilities.set(`${row},${col}`, probability);
        }

        // 找出概率最低的格子
        let minProbability = 1;
        let bestMove = null;

        for (const [key, probability] of probabilities) {
            if (probability < minProbability) {
                minProbability = probability;
                const [row, col] = key.split(',').map(Number);
                bestMove = { row, col };
            }
        }

        if (bestMove && minProbability < 0.3) {
            return {
                ...bestMove,
                action: 'reveal',
                isGuess: true
            };
        }

        return null;
    }

    calculateProbability(grid, row, col, regions) {
        const cell = grid.grid[row][col];
        if (cell.revealed || cell.flagged) return 1;

        let totalProbability = 0;
        let constraintCount = 0;

        // 检查周围已揭开的格子
        const surroundingCells = grid.getSurroundingCells(row, col);
        for (const {cell: surroundingCell, row: sRow, col: sCol} of surroundingCells) {
            if (surroundingCell.revealed) {
                const remainingMines = surroundingCell.adjacentMines - 
                    this.countSurroundingFlags(grid, sRow, sCol);
                const remainingUnrevealed = this.countSurroundingUnrevealed(grid, sRow, sCol);
                
                if (remainingUnrevealed > 0) {
                    totalProbability += remainingMines / remainingUnrevealed;
                    constraintCount++;
                }
            }
        }

        // 如果没有约束，使用区域分析的结果
        if (constraintCount === 0) {
            const region = this.findRegion(regions, row, col);
            if (region) {
                return region.remainingMines / region.unrevealedCount;
            }
            return 0.2; // 默认概率
        }

        return totalProbability / constraintCount;
    }

    countSurroundingFlags(grid, row, col) {
        return grid.getSurroundingCells(row, col)
            .filter(({cell}) => cell.flagged)
            .length;
    }

    countSurroundingUnrevealed(grid, row, col) {
        return grid.getSurroundingCells(row, col)
            .filter(({cell}) => !cell.revealed && !cell.flagged)
            .length;
    }

    identifyRegions(grid, rows, cols) {
        const regions = [];
        const visited = new Set();

        for (let row = 0; row < rows; row++) {
            for (let col = 0; col < cols; col++) {
                if (!visited.has(`${row},${col}`)) {
                    const region = this.exploreRegion(grid, row, col, visited);
                    if (region.unrevealedCount > 0) {
                        regions.push(region);
                    }
                }
            }
        }

        return regions;
    }

    exploreRegion(grid, startRow, startCol, visited) {
        const region = {
            cells: [],
            unrevealedCount: 0,
            remainingMines: 0
        };

        const queue = [[startRow, startCol]];
        while (queue.length > 0) {
            const [row, col] = queue.shift();
            const key = `${row},${col}`;
            
            if (visited.has(key)) continue;
            visited.add(key);

            const cell = grid.grid[row][col];
            region.cells.push({row, col});
            
            if (!cell.revealed && !cell.flagged) {
                region.unrevealedCount++;
            }

            // 添加相邻格子到队列
            const neighbors = grid.getSurroundingCells(row, col);
            for (const {row: nRow, col: nCol} of neighbors) {
                if (!visited.has(`${nRow},${nCol}`)) {
                    queue.push([nRow, nCol]);
                }
            }
        }

        return region;
    }

    findRegion(regions, row, col) {
        return regions.find(region => 
            region.cells.some(cell => cell.row === row && cell.col === col)
        );
    }
}

module.exports = ProbabilityStrategy;