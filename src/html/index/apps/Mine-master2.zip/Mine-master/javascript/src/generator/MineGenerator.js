class MineGenerator {
    static generateMines(grid, mineCount, safeRow, safeCol) {
        const rows = grid.rows;
        const cols = grid.cols;
        const totalCells = rows * cols;
        
        if (mineCount >= totalCells) {
            throw new Error('地雷数量不能大于或等于格子总数');
        }

        // 重置网格
        for (let i = 0; i < rows; i++) {
            for (let j = 0; j < cols; j++) {
                grid.grid[i][j].reset();
            }
        }

        // 放置地雷
        let minesPlaced = 0;
        while (minesPlaced < mineCount) {
            const row = Math.floor(Math.random() * rows);
            const col = Math.floor(Math.random() * cols);
            
            // 确保不在安全区域放置地雷
            if ((row !== safeRow || col !== safeCol) && !grid.grid[row][col].isMine) {
                grid.grid[row][col].isMine = true;
                minesPlaced++;
            }
        }

        // 计算每个格子周围的地雷数
        for (let i = 0; i < rows; i++) {
            for (let j = 0; j < cols; j++) {
                if (!grid.grid[i][j].isMine) {
                    const surroundingCells = grid.getSurroundingCells(i, j);
                    grid.grid[i][j].adjacentMines = surroundingCells.filter(({cell}) => cell.isMine).length;
                }
            }
        }

        grid.mineCount = mineCount;
        return grid;
    }
}

module.exports = MineGenerator;