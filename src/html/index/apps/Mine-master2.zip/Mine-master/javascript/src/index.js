const Game = require('./core/Game');
const AI = require('./ai/AI');
const Statistics = require('./utils/Statistics');
const Logger = require('./utils/Logger');
const { DIFFICULTY_LEVELS, DEFAULT_SIMULATION_COUNT } = require('./config/GameConfig');

class MinesweeperSimulator {
    constructor() {
        this.ai = new AI();
        this.stats = new Statistics();
        this.logger = new Logger({
            logLevel: 'info',
            logFile: 'minesweeper_simulation.log'
        });
        // 添加失败案例存储
        this.failureCases = [];
    }

    async runSimulation(difficulty = 'BEGINNER', count = DEFAULT_SIMULATION_COUNT) {
        this.stats.reset();
        const level = {
            ...DIFFICULTY_LEVELS[difficulty],
            difficulty  // 添加难度标识
        };

        for (let i = 0; i < count; i++) {
            await this.logger.info(`Starting game ${i + 1} of ${count}`);
            const startTime = Date.now();
            const result = await this.playGame(level);
            const endTime = Date.now();
            
            this.stats.recordGame(
                result.won,
                difficulty,
                result.moves,
                endTime - startTime,
                result.strategiesUsed
            );
        }

        const report = this.stats.generateReport();
        await this.logger.info('Simulation completed', report);
        return report;
    }

    async playGame(level) {
        const game = new Game(level.difficulty || 'BEGINNER');
        const strategiesUsed = new Set();
        let moves = 0;
        // 添加移动历史记录
        game.moveHistory = [];

        while (!game.gameOver) {
            const move = this.ai.makeMove(game);
            if (!move) {
                await this.logger.warn('No valid move found');
                break;
            }

            moves++;
            strategiesUsed.add(move.strategy);
            
            // 记录移动历史
            game.moveHistory.push({
                ...move,
                success: true
            });
            
            if (move.action === 'flag') {
                game.flagCell(move.row, move.col);
            } else {
                const success = game.makeMove(move.row, move.col);
                if (!success) {
                    // 记录失败的移动
                    game.moveHistory[game.moveHistory.length - 1].success = false;
                    
                    // 只有非第一步踩雷才保存失败案例
                    if (moves > 1) {
                        await this.saveFailureCase({
                            difficulty: level.difficulty,
                            finalGrid: game.grid,
                            lastMove: move,
                            moves: moves,
                            timestamp: new Date().toISOString(),
                            // 添加分析信息
                            analysis: {
                                revealedCount: this.countRevealedCells(game.grid),
                                flaggedCount: this.countFlaggedCells(game.grid),
                                totalMines: game.mineCount,
                                remainingMines: game.mineCount - this.countFlaggedCells(game.grid),
                                lastMoves: this.getLastNMoves(game, 5),
                                surroundingInfo: this.getSurroundingNumbers(game.grid, move.row, move.col),
                                strategy: move.strategy,
                                moveNumber: moves,
                                progress: (this.countRevealedCells(game.grid) / (game.grid.rows * game.grid.cols) * 100).toFixed(2) + '%'
                            }
                        });
                    }
                    break;
                }
            }

            await this.logger.logGameState(game, move);
        }

        return {
            won: game.gameWon,
            moves,
            strategiesUsed: Array.from(strategiesUsed)
        };
    }

    async saveFailureCase(failureCase) {
        const fs = require('fs').promises;
        const path = require('path');
        
        // 创建专门的失败案例目录
        const failureCasesDir = path.join(__dirname, '..', 'failure_cases');
        try {
            await fs.mkdir(failureCasesDir, { recursive: true });
        } catch (error) {
            if (error.code !== 'EEXIST') {
                throw error;
            }
        }

        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const filename = path.join(failureCasesDir, `failure_case_${timestamp}.json`);

        try {
            await fs.writeFile(
                filename,
                JSON.stringify(failureCase, null, 2)
            );
            await this.logger.info(`Failure case saved to ${filename}`);
        } catch (error) {
            await this.logger.error('Failed to save failure case', error);
        }
    }
    // 添加辅助方法
    countRevealedCells(grid) {
        let count = 0;
        for (let row = 0; row < grid.rows; row++) {
            for (let col = 0; col < grid.cols; col++) {
                if (grid.grid[row][col].revealed) count++;
            }
        }
        return count;
    }

    countFlaggedCells(grid) {
        let count = 0;
        for (let row = 0; row < grid.rows; row++) {
            for (let col = 0; col < grid.cols; col++) {
                if (grid.grid[row][col].flagged) count++;
            }
        }
        return count;
    }

    getSurroundingNumbers(grid, row, col) {
        const numbers = [];
        for (let i = -1; i <= 1; i++) {
            for (let j = -1; j <= 1; j++) {
                const newRow = row + i;
                const newCol = col + j;
                if (newRow >= 0 && newRow < grid.rows && 
                    newCol >= 0 && newCol < grid.cols) {
                    const cell = grid.grid[newRow][newCol];
                    if (cell.revealed && !cell.isMine) {
                        numbers.push({
                            row: newRow,
                            col: newCol,
                            value: cell.adjacentMines
                        });
                    }
                }
            }
        }
        return numbers;
    }

    getLastNMoves(game, n) {
        // 假设Game类有moveHistory属性记录移动历史
        if (!game.moveHistory) return [];
        return game.moveHistory.slice(-n).map(move => ({
            row: move.row,
            col: move.col,
            strategy: move.strategy,
            result: move.success ? 'success' : 'failure'
        }));
    }
}

// 运行示例
async function runExample() {
    const simulator = new MinesweeperSimulator();
    const report = await simulator.runSimulation('EXPERT', 100);  // 修改这里从 'BEGINNER' 到 'EXPERT'
    
    console.log('\n扫雷AI模拟结果报告');
    console.log('================\n');
    
    console.log('总体统计：');
    console.log(`总游戏局数：${report.summary.totalGames} 局`);
    console.log(`胜率：${report.summary.winRate}`);
    console.log(`平均每局步数：${report.summary.averageMoves} 步`);
    console.log(`平均每局用时：${report.summary.averageTime} 秒\n`);
    
    console.log('难度级别统计：');
    Object.entries(report.difficultyBreakdown).forEach(([difficulty, stats]) => {
        console.log(`\n${difficulty}难度：`);
        console.log(`- 总局数：${stats.total} 局`);
        console.log(`- 胜利：${stats.wins} 局`);
        console.log(`- 胜率：${((stats.wins / stats.total) * 100).toFixed(2)}%`);
        console.log(`- 平均步数：${stats.avgMoves.toFixed(2)} 步`);
        console.log(`- 平均用时：${(stats.avgTime / 1000).toFixed(2)} 秒`);
    });
    
    console.log('\n策略使用统计：');
    Object.entries(report.strategyUsage).forEach(([strategy, count]) => {
        console.log(`- ${strategy}：使用 ${count} 次`);
    });
}

if (require.main === module) {
    runExample().catch(console.error);
}

module.exports = MinesweeperSimulator;