class Statistics {
    constructor() {
        this.reset();
    }

    reset() {
        this.totalGames = 0;
        this.wins = 0;
        this.losses = 0;
        this.totalMoves = 0;
        this.strategyUsage = new Map();
        this.difficultyStats = new Map();
        this.averageTime = 0;
        this.totalTime = 0;
    }

    recordGame(result, difficulty, moves, time, strategiesUsed) {
        this.totalGames++;
        this.totalMoves += moves;
        this.totalTime += time;
        this.averageTime = this.totalTime / this.totalGames;

        if (result) {
            this.wins++;
        } else {
            this.losses++;
        }

        // 记录策略使用情况
        strategiesUsed.forEach(strategy => {
            const strategyName = strategy || '未知策略';
            const count = this.strategyUsage.get(strategyName) || 0;
            this.strategyUsage.set(strategyName, count + 1);
        });

        // 记录难度级别统计
        const diffStats = this.difficultyStats.get(difficulty) || {
            total: 0,
            wins: 0,
            avgMoves: 0,
            avgTime: 0
        };
        diffStats.total++;
        if (result) diffStats.wins++;
        diffStats.avgMoves = (diffStats.avgMoves * (diffStats.total - 1) + moves) / diffStats.total;
        diffStats.avgTime = (diffStats.avgTime * (diffStats.total - 1) + time) / diffStats.total;
        this.difficultyStats.set(difficulty, diffStats);
    }

    generateReport() {
        return {
            summary: {
                totalGames: this.totalGames,
                winRate: (this.wins / this.totalGames * 100).toFixed(2) + '%',
                averageMoves: (this.totalMoves / this.totalGames).toFixed(2),
                averageTime: (this.averageTime / 1000).toFixed(2) + 's'
            },
            difficultyBreakdown: Object.fromEntries(this.difficultyStats),
            strategyUsage: Object.fromEntries(this.strategyUsage)
        };
    }
}

module.exports = Statistics;