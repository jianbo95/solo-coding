const Cell = require('./Cell');

class Grid {
    constructor(rows, cols) {
        this.rows = rows;
        this.cols = cols;
        this.grid = this.initializeGrid();
        this.mineCount = 0;
    }

    initializeGrid() {
        const grid = [];
        for (let i = 0; i < this.rows; i++) {
            grid[i] = [];
            for (let j = 0; j < this.cols; j++) {
                grid[i][j] = new Cell();
            }
        }
        return grid;
    }

    isValidPosition(row, col) {
        return row >= 0 && row < this.rows && col >= 0 && col < this.cols;
    }

    getCell(row, col) {
        if (this.isValidPosition(row, col)) {
            return this.grid[row][col];
        }
        return null;
    }

    getSurroundingCells(row, col) {
        const surroundingCells = [];
        for (let i = -1; i <= 1; i++) {
            for (let j = -1; j <= 1; j++) {
                if (i === 0 && j === 0) continue;
                const newRow = row + i;
                const newCol = col + j;
                if (this.isValidPosition(newRow, newCol)) {
                    surroundingCells.push({
                        cell: this.grid[newRow][newCol],
                        row: newRow,
                        col: newCol
                    });
                }
            }
        }
        return surroundingCells;
    }

    revealCell(row, col) {
        const cell = this.getCell(row, col);
        if (!cell || cell.revealed || cell.flagged) return true;

        const result = cell.reveal();
        if (!result) return false; // 点到雷了

        // 如果是空格（周围没有雷），则揭开周围的格子
        if (cell.adjacentMines === 0) {
            const surroundingCells = this.getSurroundingCells(row, col);
            for (const {row: r, col: c} of surroundingCells) {
                this.revealCell(r, c);
            }
        }
        return true;
    }

    toJSON() {
        return {
            grid: this.grid,
            rows: this.rows,
            cols: this.cols,
            mineCount: this.mineCount
        };
    }
}

module.exports = Grid;