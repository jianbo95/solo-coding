class RegionStrategy {
    constructor() {
        this.name = '区域分析策略';
    }
    analyze(grid, rows, cols) {
        const regions = this.findIndependentRegions(grid, rows, cols);
        
        for (const region of regions) {
            const move = this.analyzeRegion(grid, region);
            if (move) return move;
        }

        return null;
    }

    findIndependentRegions(grid, rows, cols) {
        const regions = [];
        const visited = new Set();

        for (let row = 0; row < rows; row++) {
            for (let col = 0; col < cols; col++) {
                if (!visited.has(`${row},${col}`)) {
                    const region = this.exploreRegion(grid, row, col, visited);
                    if (region.cells.length > 0) {
                        regions.push(region);
                    }
                }
            }
        }

        return regions;
    }

    exploreRegion(grid, startRow, startCol, visited) {
        const region = {
            cells: [],
            borderCells: [],
            unrevealedCount: 0,
            flagCount: 0
        };

        const queue = [[startRow, startCol]];
        while (queue.length > 0) {
            const [row, col] = queue.shift();
            const key = `${row},${col}`;
            
            if (visited.has(key)) continue;
            visited.add(key);

            const cell = grid.grid[row][col];
            if (!cell.revealed) {
                if (cell.flagged) {
                    region.flagCount++;
                } else {
                    region.unrevealedCount++;
                }
                region.cells.push({row, col, cell});
            } else if (cell.adjacentMines > 0) {
                region.borderCells.push({row, col, cell});
            }

            // 添加相邻的未揭开格子
            const neighbors = grid.getSurroundingCells(row, col);
            for (const neighbor of neighbors) {
                const neighborKey = `${neighbor.row},${neighbor.col}`;
                if (!visited.has(neighborKey) && !neighbor.cell.revealed) {
                    queue.push([neighbor.row, neighbor.col]);
                }
            }
        }

        return region;
    }

    analyzeRegion(grid, region) {
        // 如果区域内所有未揭开的格子数等于剩余雷数，全部标记为雷
        let remainingMines = this.calculateRemainingMines(grid, region);
        if (remainingMines === region.unrevealedCount && region.unrevealedCount > 0) {
            const unrevealed = region.cells.find(({cell}) => !cell.revealed && !cell.flagged);
            if (unrevealed) {
                return {
                    row: unrevealed.row,
                    col: unrevealed.col,
                    action: 'flag'
                };
            }
        }

        // 如果区域内已标记的雷数等于总雷数，其他格子都是安全的
        if (remainingMines === 0 && region.unrevealedCount > 0) {
            const unrevealed = region.cells.find(({cell}) => !cell.revealed && !cell.flagged);
            if (unrevealed) {
                return {
                    row: unrevealed.row,
                    col: unrevealed.col,
                    action: 'reveal'
                };
            }
        }

        return null;
    }

    calculateRemainingMines(grid, region) {
        let totalRequired = 0;
        for (const {row, col, cell} of region.borderCells) {
            const surroundingFlags = grid.getSurroundingCells(row, col)
                .filter(({cell}) => cell.flagged)
                .length;
            totalRequired += cell.adjacentMines - surroundingFlags;
        }
        return totalRequired;
    }
}

module.exports = RegionStrategy;