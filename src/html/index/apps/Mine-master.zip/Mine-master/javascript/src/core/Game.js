const Grid = require('./Grid');
const { DIFFICULTY_LEVELS } = require('../config/GameConfig');
const MineGenerator = require('../generator/MineGenerator');

class Game {
    constructor(difficulty = 'BEGINNER') {
        // 如果传入的是字符串，从 DIFFICULTY_LEVELS 获取配置
        const level = typeof difficulty === 'string' 
            ? DIFFICULTY_LEVELS[difficulty]
            : difficulty;

        if (!level || !level.rows || !level.cols || !level.mines) {
            throw new Error('Invalid difficulty level configuration');
        }

        this.rows = level.rows;
        this.cols = level.cols;
        this.mineCount = level.mines;
        this.grid = new Grid(this.rows, this.cols);
        this.gameOver = false;
        this.gameWon = false;
        this.moveCount = 0;
    }

    initialize(firstRow, firstCol) {
        // 生成地图时确保第一次点击的位置是安全的
        this.grid = MineGenerator.generateMines(this.grid, this.mineCount, firstRow, firstCol);
        return this.grid;
    }

    makeMove(row, col) {
        if (this.gameOver) return false;
        
        // 如果是第一步，先初始化地图
        if (this.moveCount === 0) {
            this.initialize(row, col);
        }
        
        const success = this.grid.revealCell(row, col);
        if (success) {
            this.moveCount++;
            this.checkWinCondition();
        } else {
            this.gameOver = true;
        }
        
        return success;
    }

    checkWinCondition() {
        let unrevealedSafeCells = 0;
        for (let i = 0; i < this.rows; i++) {
            for (let j = 0; j < this.cols; j++) {
                const cell = this.grid.grid[i][j];
                if (!cell.revealed && !cell.isMine) {
                    unrevealedSafeCells++;
                }
            }
        }
        if (unrevealedSafeCells === 0) {
            this.gameOver = true;
            this.gameWon = true;
        }
    }

    flagCell(row, col) {
        if (this.gameOver) return;
        const cell = this.grid.getCell(row, col);
        if (cell && !cell.revealed) {
            cell.flag();
        }
    }

    checkWinCondition() {
        let unrevealedCount = 0;
        let correctFlags = 0;

        for (let i = 0; i < this.rows; i++) {
            for (let j = 0; j < this.cols; j++) {
                const cell = this.grid.grid[i][j];
                if (!cell.revealed) unrevealedCount++;
                if (cell.flagged && cell.isMine) correctFlags++;
            }
        }

        if (unrevealedCount === this.mineCount || correctFlags === this.mineCount) {
            this.gameOver = true;
            this.gameWon = true;
        }
    }

    getGameState() {
        return {
            grid: this.grid.toJSON(),
            gameOver: this.gameOver,
            gameWon: this.gameWon,
            moveCount: this.moveCount
        };
    }
}

module.exports = Game;