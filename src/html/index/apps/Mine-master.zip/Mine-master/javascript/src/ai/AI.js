const BasicStrategy = require('./strategies/BasicStrategy');
const PatternStrategy = require('./strategies/PatternStrategy');
const ProbabilityStrategy = require('./strategies/ProbabilityStrategy');
const RegionStrategy = require('./strategies/RegionStrategy');

class AI {
    constructor() {
        this.strategies = [
            new BasicStrategy(),
            new PatternStrategy(),
            new RegionStrategy(),
            new ProbabilityStrategy()
        ];
    }

    makeMove(game) {
        // 如果是第一步，选择中心位置而不是角落
        if (game.moveCount === 0) {
            return {
                row: Math.floor(game.rows / 2),
                col: Math.floor(game.cols / 2),
                action: 'reveal',
                strategy: '首次移动策略'
            };
        }

        // 先尝试确定性策略
        for (const strategy of this.strategies) {
            if (strategy instanceof BasicStrategy || 
                strategy instanceof PatternStrategy || 
                strategy instanceof RegionStrategy) {
                const move = strategy.analyze(game.grid, game.rows, game.cols);
                if (move) {
                    return {
                        ...move,
                        strategy: strategy.name
                    };
                }
            }
        }

        // 如果没有确定性移动，使用概率策略
        const probStrategy = this.strategies.find(s => s instanceof ProbabilityStrategy);
        if (probStrategy) {
            const move = probStrategy.analyze(game.grid, game.rows, game.cols, game.mineCount);
            if (move && move.probability < 0.3) {  // 只在概率较低时行动
                return {
                    ...move,
                    strategy: probStrategy.name
                };
            }
        }

        // 如果概率都很高，随机选择一个未揭开的边缘格子
        const borderCells = this.findBorderCells(game.grid);
        if (borderCells.length > 0) {
            const randomCell = borderCells[Math.floor(Math.random() * borderCells.length)];
            return {
                ...randomCell,
                action: 'reveal',
                strategy: '边缘探索策略'
            };
        }

        return null;
    }

    findBorderCells(grid) {
        const borderCells = [];
        for (let i = 0; i < grid.rows; i++) {
            for (let j = 0; j < grid.cols; j++) {
                if (!grid.grid[i][j].revealed && !grid.grid[i][j].flagged) {
                    const neighbors = grid.getSurroundingCells(i, j);
                    if (neighbors.some(n => n.cell.revealed)) {
                        borderCells.push({ row: i, col: j });
                    }
                }
            }
        }
        return borderCells;
    }
}

module.exports = AI;