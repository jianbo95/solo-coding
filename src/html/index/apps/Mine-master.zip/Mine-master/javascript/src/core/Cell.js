class Cell {
    constructor() {
        this.isMine = false;
        this.revealed = false;
        this.flagged = false;
        this.adjacentMines = 0;
    }

    reveal() {
        if (!this.flagged) {
            this.revealed = true;
        }
        return !this.isMine;
    }

    flag() {
        if (!this.revealed) {
            this.flagged = !this.flagged;
        }
    }

    reset() {
        this.isMine = false;
        this.revealed = false;
        this.flagged = false;
        this.adjacentMines = 0;
    }
}

module.exports = Cell;