class PatternStrategy {
    constructor() {
        this.name = '模式识别策略';
    }
    analyze(grid, rows, cols) {
        // 检查1-2-1模式（坦克链）
        const tankChainMove = this.analyzeTankChain(grid, rows, cols);
        if (tankChainMove) return tankChainMove;

        // 检查1-2-2模式
        const oneTwoTwoMove = this.analyzeOneTwoTwo(grid, rows, cols);
        if (oneTwoTwoMove) return oneTwoTwoMove;

        // 检查1-1-1模式
        const oneOneOneMove = this.analyzeOneOneOne(grid, rows, cols);
        if (oneOneOneMove) return oneOneOneMove;

        return null;
    }

    analyzeTankChain(grid, rows, cols) {
        for (let row = 0; row < rows; row++) {
            for (let col = 0; col < cols; col++) {
                const cell = grid.grid[row][col];
                if (!cell.revealed || cell.adjacentMines !== 1) continue;

                const surroundingCells = grid.getSurroundingCells(row, col);
                const revealedTwos = surroundingCells.filter(({cell}) => 
                    cell.revealed && cell.adjacentMines === 2
                );

                for (const twoCell of revealedTwos) {
                    const twoSurrounding = grid.getSurroundingCells(twoCell.row, twoCell.col);
                    const otherOne = twoSurrounding.find(({cell, row: r, col: c}) => 
                        cell.revealed && 
                        cell.adjacentMines === 1 && 
                        (r !== row || c !== col)
                    );

                    if (otherOne) {
                        const middleUnrevealed = twoSurrounding.filter(({cell}) => 
                            !cell.revealed && !cell.flagged
                        );

                        if (middleUnrevealed.length === 1) {
                            return {
                                row: middleUnrevealed[0].row,
                                col: middleUnrevealed[0].col,
                                action: 'flag'
                            };
                        }
                    }
                }
            }
        }
        return null;
    }

    analyzeOneTwoTwo(grid, rows, cols) {
        const directions = [
            [0, 1],  // 右
            [0, -1], // 左
            [1, 0],  // 下
            [-1, 0]  // 上
        ];

        for (let row = 0; row < rows; row++) {
            for (let col = 0; col < cols; col++) {
                const cell = grid.grid[row][col];
                if (!cell.revealed || cell.adjacentMines !== 1) continue;

                for (const [dx, dy] of directions) {
                    const midRow = row + dx;
                    const midCol = col + dy;
                    const farRow = midRow + dx;
                    const farCol = midCol + dy;

                    if (!grid.isValidPosition(midRow, midCol) || 
                        !grid.isValidPosition(farRow, farCol)) continue;

                    const midCell = grid.grid[midRow][midCol];
                    const farCell = grid.grid[farRow][farCol];

                    if (midCell.revealed && midCell.adjacentMines === 2 &&
                        farCell.revealed && farCell.adjacentMines === 2) {
                        
                        const targetRow = farRow + dx;
                        const targetCol = farCol + dy;

                        if (grid.isValidPosition(targetRow, targetCol)) {
                            const targetCell = grid.grid[targetRow][targetCol];
                            if (!targetCell.revealed && !targetCell.flagged) {
                                return {
                                    row: targetRow,
                                    col: targetCol,
                                    action: 'flag'
                                };
                            }
                        }
                    }
                }
            }
        }
        return null;
    }

    analyzeOneOneOne(grid, rows, cols) {
        // 水平和垂直方向的1-1-1模式检查
        const directions = [[0, 1], [1, 0]];  // 右和下

        for (let row = 0; row < rows - 2; row++) {
            for (let col = 0; col < cols - 2; col++) {
                const cell = grid.grid[row][col];
                if (!cell.revealed || cell.adjacentMines !== 1) continue;

                for (const [dx, dy] of directions) {
                    const mid = grid.grid[row + dx][col + dy];
                    const far = grid.grid[row + 2*dx][col + 2*dy];

                    if (mid.revealed && mid.adjacentMines === 1 &&
                        far.revealed && far.adjacentMines === 1) {
                        
                        // 检查垂直于线的方向
                        const perpendicular = dx === 0 ? [[1, 0], [-1, 0]] : [[0, 1], [0, -1]];
                        
                        for (const [px, py] of perpendicular) {
                            for (let i = 0; i < 3; i++) {
                                const checkRow = row + i*dx + px;
                                const checkCol = col + i*dy + py;
                                
                                if (grid.isValidPosition(checkRow, checkCol)) {
                                    const checkCell = grid.grid[checkRow][checkCol];
                                    if (!checkCell.revealed && !checkCell.flagged) {
                                        return {
                                            row: checkRow,
                                            col: checkCol,
                                            action: 'reveal'
                                        };
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return null;
    }
}

module.exports = PatternStrategy;