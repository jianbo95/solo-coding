const Game = require('./core/Game');
const AI = require('./ai/AI');
const Statistics = require('./utils/Statistics');
const Logger = require('./utils/Logger');
const { DIFFICULTY_LEVELS, DEFAULT_SIMULATION_COUNT } = require('./config/GameConfig');

class MinesweeperSimulator {
    constructor() {
        this.ai = new AI();
        this.stats = new Statistics();
        this.logger = new Logger({
            logLevel: 'info',
            logFile: 'minesweeper_simulation.log'
        });
        // 添加失败案例存储
        this.failureCases = [];
    }

    async runSimulation(difficulty = 'BEGINNER', count = DEFAULT_SIMULATION_COUNT) {
        this.stats.reset();
        const level = {
            ...DIFFICULTY_LEVELS[difficulty],
            difficulty  // 添加难度标识
        };

        for (let i = 0; i < count; i++) {
            await this.logger.info(`Starting game ${i + 1} of ${count}`);
            const startTime = Date.now();
            const result = await this.playGame(level);
            const endTime = Date.now();
            
            this.stats.recordGame(
                result.won,
                difficulty,
                result.moves,
                endTime - startTime,
                result.strategiesUsed
            );
        }

        const report = this.stats.generateReport();
        await this.logger.info('Simulation completed', report);
        return report;
    }

    async playGame(level) {
        const game = new Game(level.difficulty || 'BEGINNER');
        const strategiesUsed = new Set();
        let moves = 0;

        while (!game.gameOver) {
            const move = this.ai.makeMove(game);
            if (!move) {
                await this.logger.warn('No valid move found');
                break;
            }

            moves++;
            strategiesUsed.add(move.strategy);
            
            if (move.action === 'flag') {
                game.flagCell(move.row, move.col);
            } else {
                const success = game.makeMove(move.row, move.col);
                if (!success) {
                    // 保存失败案例到单独文件
                    await this.saveFailureCase({
                        difficulty: level.difficulty,
                        finalGrid: game.grid,
                        lastMove: move,
                        moves: moves,
                        timestamp: new Date().toISOString()
                    });
                    break;
                }
            }

            await this.logger.logGameState(game, move);
        }

        return {
            won: game.gameWon,
            moves,
            strategiesUsed: Array.from(strategiesUsed)
        };
    }

    async saveFailureCase(failureCase) {
        const fs = require('fs').promises;
        const path = require('path');
        
        // 创建专门的失败案例目录
        const failureCasesDir = path.join(__dirname, '..', 'failure_cases');
        try {
            await fs.mkdir(failureCasesDir, { recursive: true });
        } catch (error) {
            if (error.code !== 'EEXIST') {
                throw error;
            }
        }

        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const filename = path.join(failureCasesDir, `failure_case_${timestamp}.json`);

        try {
            await fs.writeFile(
                filename,
                JSON.stringify(failureCase, null, 2)
            );
            await this.logger.info(`Failure case saved to ${filename}`);
        } catch (error) {
            await this.logger.error('Failed to save failure case', error);
        }
    }
}

// 运行示例
async function runExample() {
    const simulator = new MinesweeperSimulator();
    const report = await simulator.runSimulation('EXPERT', 100);  // 修改这里从 'BEGINNER' 到 'EXPERT'
    
    console.log('\n扫雷AI模拟结果报告');
    console.log('================\n');
    
    console.log('总体统计：');
    console.log(`总游戏局数：${report.summary.totalGames} 局`);
    console.log(`胜率：${report.summary.winRate}`);
    console.log(`平均每局步数：${report.summary.averageMoves} 步`);
    console.log(`平均每局用时：${report.summary.averageTime} 秒\n`);
    
    console.log('难度级别统计：');
    Object.entries(report.difficultyBreakdown).forEach(([difficulty, stats]) => {
        console.log(`\n${difficulty}难度：`);
        console.log(`- 总局数：${stats.total} 局`);
        console.log(`- 胜利：${stats.wins} 局`);
        console.log(`- 胜率：${((stats.wins / stats.total) * 100).toFixed(2)}%`);
        console.log(`- 平均步数：${stats.avgMoves.toFixed(2)} 步`);
        console.log(`- 平均用时：${(stats.avgTime / 1000).toFixed(2)} 秒`);
    });
    
    console.log('\n策略使用统计：');
    Object.entries(report.strategyUsage).forEach(([strategy, count]) => {
        console.log(`- ${strategy}：使用 ${count} 次`);
    });
}

if (require.main === module) {
    runExample().catch(console.error);
}

module.exports = MinesweeperSimulator;