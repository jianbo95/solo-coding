const fs = require('fs').promises;
const path = require('path');

class Logger {
    constructor(options = {}) {
        this.logLevel = options.logLevel || 'info';
        this.logFile = options.logFile || 'minesweeper.log';
        this.enableConsole = options.enableConsole !== false;
        this.levels = {
            debug: 0,
            info: 1,
            warn: 2,
            error: 3
        };
    }

    async log(level, message, data = null) {
        if (this.levels[level] < this.levels[this.logLevel]) return;

        const timestamp = new Date().toISOString();
        const logEntry = {
            timestamp,
            level,
            message,
            data
        };

        const logString = JSON.stringify(logEntry, null, 2);

        if (this.enableConsole) {
            console.log(logString);
        }

        try {
            await fs.appendFile(this.logFile, logString + '\n');
        } catch (error) {
            console.error('Failed to write to log file:', error);
        }
    }

    debug(message, data) {
        return this.log('debug', message, data);
    }

    info(message, data) {
        return this.log('info', message, data);
    }

    warn(message, data) {
        return this.log('warn', message, data);
    }

    error(message, data) {
        return this.log('error', message, data);
    }

    async logGameState(game, move) {
        await this.debug('Game State', {
            moveCount: game.moveCount,
            move,
            gridState: game.grid.toJSON()
        });
    }
}

module.exports = Logger;