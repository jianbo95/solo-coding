class BasicStrategy {
    constructor() {
        this.name = '基础逻辑策略';
    }
    analyze(grid, rows, cols) {
        // 遍历所有已揭开的格子
        for (let row = 0; row < rows; row++) {
            for (let col = 0; col < cols; col++) {
                const cell = grid.grid[row][col];
                if (!cell.revealed || cell.isMine) continue;

                const surroundingCells = grid.getSurroundingCells(row, col);
                const unrevealedCells = surroundingCells.filter(({cell}) => !cell.revealed && !cell.flagged);
                const flaggedCells = surroundingCells.filter(({cell}) => cell.flagged);

                // 如果未标记的雷数等于未揭开的格子数，所有未揭开的格子都是雷
                if (cell.adjacentMines - flaggedCells.length === unrevealedCells.length && unrevealedCells.length > 0) {
                    return {
                        row: unrevealedCells[0].row,
                        col: unrevealedCells[0].col,
                        action: 'flag'
                    };
                }

                // 如果已标记的雷数等于周围的雷数，其他未揭开的格子都是安全的
                if (cell.adjacentMines === flaggedCells.length && unrevealedCells.length > 0) {
                    return {
                        row: unrevealedCells[0].row,
                        col: unrevealedCells[0].col,
                        action: 'reveal'
                    };
                }
            }
        }

        return null;
    }
}

module.exports = BasicStrategy;